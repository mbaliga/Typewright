# Hyle multi-script template pack

One folder per script under `svg/`. Each file is a single glyph template with the
correct metric guides for that script already drawn in, plus a faint reference
glyph so you can see where the shape sits. You draw the glyph, then delete the
reference.

## Folders and counts

| script | folder | templates | notes |
| --- | --- | --- | --- |
| Latin | svg/Latin | 120 | finish first, ship to Google Fonts |
| Hiragana | svg/Hiragana | 55 | bases plus small kana; voiced forms compose from the dakuten mark |
| Katakana | svg/Katakana | 57 | same structure as Hiragana |
| Devanagari | svg/Devanagari | 68 | vowels, consonants, matras, digits; conjuncts come later in shaping |
| Naskh | svg/Naskh | 49 | isolated base letters; positional forms generated at build |
| Nastaliq | svg/Nastaliq | 49 | same bases; only start this if Nastaliq becomes the whole point |

## Layers in every file

- `guides` red horizontal metric lines and blue vertical advance lines. Never move
  or export these.
- `reference_delete_me` a faint grey reference glyph at low opacity, so you can
  position and size your drawing. It is a reference only. Delete it before export.
- `DRAW_HERE` empty. Your glyph goes here.

## The five rules that keep the conversion clean

1. Filled shapes, not strokes. Run Outline Stroke before exporting.
2. One closed shape per glyph. Counters stay as holes inside it.
3. As few points as the shape needs. Curves for curves, not many short lines.
4. Do not scale after drawing. Draw at final size inside the guides.
5. Round shapes overshoot the baseline and top by about 8 to 10 units; flat shapes
   sit exactly on the lines.

## Script-specific notes

- Hiragana and Katakana: design to an optical centre, not a baseline. The glyph
  fills a near-square body from about -120 to 880. Keep counters open and even.
- Devanagari: the shirorekha, the top headline at 700, connects most letters. Draw
  each letter hanging from it. The i-matra and conjunct behaviour is handled in the
  font's shaping rules, not by you drawing every combination.
- Naskh: right to left. Draw the isolated form of each letter. The four positional
  shapes (isolated, initial, medial, final) are generated at build time from your
  isolated drawing plus join rules; if you want to draw them by hand for control,
  say so and the pack can be expanded to four cells per letter.

## Sending back

Export as SVG, keep the file names, zip, send. Names are how the font matches each
drawing to its character.
